from setuptools import setup

setup(
    name='va_module',
    version='1.1',
    description='The real equation of Programing',
    author='Bernard',
    author_email='fmoney91.eb@gmail.com',
    url='trello.com/pa',
    py_modules=['va_module'],
)
